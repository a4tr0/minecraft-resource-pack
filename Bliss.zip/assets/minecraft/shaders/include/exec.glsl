void apply() {
	if (all(lessThan(abs(texture(Sampler0, texCoord0)-targetColor), vec4(1e-3)))) {
        vec2 aa1 = (vertexPos.xyz / vertexPos.w).xy * 0.5 + 0.5;
        vec4 ttc = vertexColor * ColorModulator;
        vec2 uv = aa1;
        uv *=  1.0 - uv.yx;
        float vig = uv.x*uv.y * 10.0;
        vig = pow(vig, 0.35);
        uv = aa1 * 6.0 - vec2(GameTime * 500, 0.0);
        vec3 X = vec3(uv, mod(GameTime * 500.0, 578.0) * 0.8660254037844386);
        vec4 nr = os2NoiseWithDerivatives_ImproveXY(X);
        vec3 col = ttc.rgb * (0.9 + 0.5 * os2NoiseWithDerivatives_ImproveXY(X - nr.xyz / 16.0).w);
        col += ttc.rgb * (0.1 + 0.5 * nr.w);

        fragColor = vec4(col, (0.75 - vig) * vertexColor.a * ColorModulator.a * 1.2);
    }
}