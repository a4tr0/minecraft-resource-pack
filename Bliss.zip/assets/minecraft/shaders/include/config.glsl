// What color to detect from the unicode texture
#define targetColor vec4(1.0, 0.533, 0.0, 1.0)